HW3 Submission - Krish Harjani

Answers to problem 2 included in hw3q2.txt
